import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mymedia',
  templateUrl: './mymedia.component.html',
  styleUrls: ['./mymedia.component.css']
})
export class MymediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
