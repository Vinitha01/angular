import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from 'src/app/signup/signup.component';
import { MainContentComponent } from 'src/app/main-content/main-content.component';
import { ImageuploadComponent } from 'src/app/imageupload/imageupload.component';
import { NavbarComponent } from 'src/app/navbar/navbar.component';
import {SigninComponent} from 'src/app/signin/signin.component';
import { FollowComponent } from './follow/follow.component';
import { MymediaComponent } from './mymedia/mymedia.component';


const routes: Routes = [
  {path:'',pathMatch:'full', redirectTo:'home'},
  { path: 'images', component: ImageuploadComponent },
  { path: 'home', component: MainContentComponent },
  {path:'signup',component: SignupComponent},
  {path:'signin',component: SigninComponent},
  {path:'follow',component: FollowComponent},
  {path:'mymedia',component: MymediaComponent} 

 
    ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
